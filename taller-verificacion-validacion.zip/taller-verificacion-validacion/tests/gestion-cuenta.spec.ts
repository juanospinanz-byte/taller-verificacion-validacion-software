
import { test, expect } from '@playwright/test';

test('Gestión de Cuenta', async ({ page }) => {
  const randomUsername = 'user' + Math.random().toString(36).substring(2, 10);
  const randomPassword = 'pass' + Math.random().toString(36).substring(2, 12) + '!';
  const nombres = ['Juan', 'Carlos', 'Ana', 'Maria', 'Luis', 'Pedro', 'Laura', 'Sofia'];
  const randomFirstName = nombres[Math.floor(Math.random() * nombres.length)];
  const apellidos = ['Gonzalez', 'Rodriguez', 'Lopez', 'Martinez', 'Garcia', 'Perez', 'Sanchez', 'Ramirez'];
  const randomLastName = apellidos[Math.floor(Math.random() * apellidos.length)];
  const randomEmail = 'user' + Math.floor(Math.random() * 10000) + '@gmail.com';
  const randomPhone = '3' + Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
  const calles = ['Calle', 'Avenida', 'Carrera', 'Diagonal', 'Transversal'];
  const numeros = Math.floor(Math.random() * 1000) + 1;
  const randomAddress1 = calles[Math.floor(Math.random() * calles.length)] + ' ' + numeros + ' # ' + (Math.floor(Math.random() * 100) + 1);
  const randomAddress2 = 'Apto ' + (Math.floor(Math.random() * 500) + 1) + ' - ' + (Math.floor(Math.random() * 10) + 1);
  const ciudades = ['Medellín', 'Bogotá', 'Cali', 'Barranquilla', 'Cartagena', 'Bucaramanga', 'Pereira', 'Manizales', 'Cúcuta', 'Armenia', 'Ibagué', 'Villavicencio', 'Santa Marta', 'Montería', 'Valledupar', 'Popayán', 'Sincelejo', 'Tunja', 'Riohacha', 'Quibdó'];
  const randomCity = ciudades[Math.floor(Math.random() * ciudades.length)];
  const departamentos = ['Antioquia', 'Bogotá D.C.', 'Valle del Cauca', 'Atlántico', 'Bolívar', 'Santander', 'Risaralda', 'Caldas', 'Norte de Santander', 'Quindío', 'Tolima', 'Meta', 'Magdalena', 'Córdoba', 'Cesar', 'Cauca', 'Sucre', 'Boyacá', 'La Guajira', 'Chocó', 'Nariño', 'Huila', 'Cundinamarca', 'Casanare', 'Arauca', 'Putumayo', 'Amazonas', 'Guainía', 'Guaviare', 'Vaupés', 'Vichada', 'San Andrés'];
  const randomState = departamentos[Math.floor(Math.random() * departamentos.length)];
  const zipCodes: { [key: string]: string } = {
    'Medellín': '050001', 'Bogotá': '110001', 'Cali': '760001', 'Barranquilla': '080001',
    'Cartagena': '130001', 'Bucaramanga': '680001', 'Pereira': '660001', 'Manizales': '170001',
    'Cúcuta': '540001', 'Armenia': '630001', 'Ibagué': '730001', 'Villavicencio': '500001',
    'Santa Marta': '470001', 'Montería': '230001', 'Valledupar': '200001', 'Popayán': '190001',
    'Sincelejo': '700001', 'Tunja': '150001', 'Riohacha': '440001', 'Quibdó': '270001'
  };
  const randomZip = zipCodes[randomCity] || '110001';

  await page.goto('https://jpetstore.aspectran.com/');

  await page.click('text=Sign Up');
  await page.fill('input[name="username"]', randomUsername);
  await page.fill('input[name="password"]', randomPassword);
  await page.fill('input[name="repeatedPassword"]', randomPassword);
  await page.fill('input[name="firstName"]', randomFirstName);
  await page.fill('input[name="lastName"]', randomLastName);
  await page.fill('input[name="email"]', randomEmail);
  await page.fill('input[name="phone"]', randomPhone);
  await page.fill('input[name="address1"]', randomAddress1);
  await page.fill('input[name="address2"]', randomAddress2);
  await page.fill('input[name="city"]', randomCity);
  await page.fill('input[name="state"]', randomState);
  await page.fill('input[name="zip"]', randomZip);
  await page.fill('input[name="country"]', 'colombia');
  await page.check('input[name="listOption"]');
  await page.click('button[type="submit"]:has-text("Save Account Information")');

  await page.click('button[type="submit"]:has-text("Login")');

  await page.click('#dropdownMenuButton');
  await page.click('text=My Account');

  await page.fill('input[name="password"]', randomUsername);
  await page.fill('input[name="repeatedPassword"]', randomUsername);
  await page.fill('input[name="firstName"]', randomFirstName);
  await page.fill('input[name="lastName"]', randomLastName);
  await page.fill('input[name="email"]', randomEmail);
  await page.fill('input[name="phone"]', randomPhone);
  await page.fill('input[name="address1"]', randomAddress1);
  await page.fill('input[name="address2"]', randomAddress2);
  await page.fill('input[name="city"]', randomCity);
  await page.fill('input[name="state"]', randomState);
  await page.fill('input[name="zip"]', randomState);
  await page.fill('input[name="country"]', 'colombia');

  await page.click('button[type="submit"]:has-text("Save Account Information")');
});